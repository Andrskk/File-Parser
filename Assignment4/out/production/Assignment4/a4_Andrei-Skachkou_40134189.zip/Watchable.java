/**
 * Interface to implement by TVShow class
 */
public interface Watchable {

    boolean isOnSameTime(TVShow S);
}
